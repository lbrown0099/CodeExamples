package stringMethods1;

public class stringMethods1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String [] words = {"funk", "chunk", "furry", "baconator"};
		
		//for loop that finds words that start with fu
		for (String w : words) {
			if (w.startsWith("fu"))
				System.out.println(w + " starts with fu");
		}
		
		
		//this string searches for the first instance of o and returns its place
		//also ignores the first 10 characters in the string
		String s = "leighabrownscomputerisgreat";
		System.out.println(s.indexOf('o', 10)); 
		
		
	}

}
